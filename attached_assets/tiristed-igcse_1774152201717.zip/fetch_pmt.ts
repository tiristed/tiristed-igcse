const fetchPMT = async () => {
    const res = await fetch('https://www.physicsandmathstutor.com/biology-revision/igcse-cie/');
    const text = await res.text();
    const matches = text.match(/href="([^"]+)"/g);
    if (matches) {
        console.log(matches.filter(m => m.includes('topic')).slice(0, 20));
    }
};
fetchPMT();

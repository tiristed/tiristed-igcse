const https = require('https');

https.get('https://www.physicsandmathstutor.com/biology-revision/igcse-cie/', (resp) => {
  let data = '';
  resp.on('data', (chunk) => { data += chunk; });
  resp.on('end', () => {
    const matches = data.match(/href="([^"]+)"/g);
    if (matches) {
        console.log(matches.filter(m => m.includes('topic')).slice(0, 20));
    }
  });
}).on("error", (err) => {
  console.log("Error: " + err.message);
});

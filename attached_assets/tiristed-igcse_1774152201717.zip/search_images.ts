import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

async function searchImages() {
  const queries = [
    "MRS GREN characteristics of living organisms diagram",
    "Animal cell structure diagram labeled",
    "Plant cell structure diagram labeled",
    "Human heart structure diagram labeled",
    "Human respiratory system lungs diagram labeled",
    "Human kidney structure diagram labeled",
    "Human eye structure diagram labeled"
  ];

  for (const query of queries) {
    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: `Find a direct URL to a high-quality educational diagram image for: "${query}". Return ONLY a JSON object with {"query": "${query}", "url": "https://..."}. Ensure the URL is a direct link to an image (e.g., .png, .jpg) from a reliable educational source like Wikimedia Commons or similar.`,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json"
      }
    });
    console.log(response.text);
  }
}

searchImages().catch(console.error);

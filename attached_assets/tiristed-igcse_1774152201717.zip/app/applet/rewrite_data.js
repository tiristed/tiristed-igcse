import fs from 'fs';

const pmtNotes = JSON.parse(fs.readFileSync('/app/applet/pmt_notes.json', 'utf8'));

const getPmtNote = (topicNumber) => {
    // PMT notes are ordered 1 to 21
    const note = pmtNotes[topicNumber - 1];
    if (!note) return null;
    return {
        id: `pmt-${topicNumber}`,
        title: `${topicNumber}. ${note.title} (PMT Summary Notes)`,
        content: `Loading PDF...`,
        pdfUrl: note.pdfUrl
    };
};

const rewriteData = (file, startTopic, endTopic) => {
    let content = fs.readFileSync(file, 'utf8');
    
    for (let i = startTopic; i <= endTopic; i++) {
        const pmtNote = getPmtNote(i);
        if (!pmtNote) continue;
        
        // Find the topic block
        // We want to replace everything inside notes: [ ... ] for this topic
        // Regex to match the notes array for a specific topic ID
        const topicRegex = new RegExp(`(id:\\s*'bio-${i}',[\\s\\S]*?notes:\\s*\\[)([\\s\\S]*?)(\\]\\s*\\})`, 'g');
        
        content = content.replace(topicRegex, (match, p1, p2, p3) => {
            const newNoteStr = `
        {
          id: '${pmtNote.id}',
          title: '${pmtNote.title.replace(/'/g, "\\'")}',
          content: '',
          pdfUrl: '${pmtNote.pdfUrl}'
        }
            `;
            return p1 + newNoteStr + p3;
        });
    }
    
    fs.writeFileSync(file, content);
};

rewriteData('/app/applet/src/data/biologyData.ts', 1, 10);
rewriteData('/app/applet/src/data/biologyData2.ts', 11, 21);

console.log("Done rewriting data files.");

const fetchPMT = async () => {
    const res = await fetch('https://www.physicsandmathstutor.com/biology-revision/igcse-cie/', {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
    });
    const text = await res.text();
    console.log(text.substring(0, 500));
    console.log(text.includes('Cloudflare'));
};
fetchPMT();

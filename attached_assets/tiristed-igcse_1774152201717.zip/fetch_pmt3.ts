import * as fs from 'fs';

const fetchPMT = async () => {
    const res = await fetch('https://www.physicsandmathstutor.com/biology-revision/igcse-cie/', {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
    });
    const text = await res.text();
    const matches = text.match(/href="([^"]+)"/g);
    if (!matches) return;
    
    const links = matches.map(m => m.replace('href="', '').replace('"', ''));
    const topicLinks = links.filter(l => l.includes('biology-revision/igcse-cie/') && l !== 'https://www.physicsandmathstutor.com/biology-revision/igcse-cie/');
    
    // Deduplicate
    const uniqueTopics = [...new Set(topicLinks)];
    console.log(`Found ${uniqueTopics.length} topics`);
    
    const allNotes = [];
    
    for (const topicUrl of uniqueTopics) {
        console.log(`Fetching ${topicUrl}...`);
        const topicRes = await fetch(topicUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
        });
        const topicText = await topicRes.text();
        const topicMatches = topicText.match(/href="([^"]+)"/g);
        if (topicMatches) {
            const tLinks = topicMatches.map(m => m.replace('href="', '').replace('"', ''));
            // Find Summary Notes PDF
            const summaryNotes = tLinks.filter(l => l.includes('.pdf') && l.includes('Summary'));
            if (summaryNotes.length > 0) {
                // Get the topic title from URL
                const titleMatch = topicUrl.match(/igcse-cie\/([^\/]+)/);
                const title = titleMatch ? titleMatch[1].replace(/-/g, ' ') : 'Unknown Topic';
                
                allNotes.push({
                    id: titleMatch ? titleMatch[1] : Math.random().toString(),
                    title: title.charAt(0).toUpperCase() + title.slice(1),
                    pdfUrl: summaryNotes[0].replace(/ /g, '%20')
                });
                console.log(`Found notes for ${title}`);
            }
        }
    }
    
    fs.writeFileSync('/app/applet/pmt_notes.json', JSON.stringify(allNotes, null, 2));
    console.log("Done!");
};
fetchPMT();
